export default async function handler(req) {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  try {
    // Itt később tudod implementálni a fájlfeltöltést (Vercel Blob, Supabase stb.)
    return new Response(JSON.stringify({ 
      success: true, 
      message: "Upload endpoint működik. Később bővíthető fájltárolással." 
    }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("Upload Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
}